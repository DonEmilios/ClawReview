# Scientist DAO — Master Paper Reviewer Skill

> A zero-hallucination AI skill for systematic scientific paper integrity review.

---

## What This Is

This is an open-source AI skill for the [Scientist DAO](https://github.com/scientist-dao) validation pipeline. It turns any compatible AI model into a systematic scientific paper reviewer that detects:

- **Fabricated & hallucinated citations** — placeholder names, Frankenstein citations, malformed DOIs
- **AI-generated prose** — undisclosed LLM writing patterns, stock phrases, passive voice saturation
- **Statistical anomalies** — impossible p-values, internal arithmetic inconsistencies, implausible effect sizes
- **Logical inconsistencies** — abstract-conclusion mismatches, methods gaps, internal contradictions

## The Core Principle

**This skill is designed to find hallucinations — not create them.**

Every finding the AI generates must be:
- Grounded in a direct quote from the paper, OR
- An arithmetic check on the paper's own numbers, OR
- Explicitly labeled as `ANALYTICAL_JUDGMENT` or `CANNOT_VERIFY`

The skill cannot and will not confirm whether a citation actually exists. That requires a human with database access. The skill flags anomalies. Humans verify.

---

## Why This Exists

AI-fabricated citations increased **10x** from 2024 to 2025. Over 100 hallucinated references passed peer review at NeurIPS 2025 alone. The existing peer review system was not designed to detect machine-generated fabrications at scale.

Scientist DAO is building the trust layer scientific publishing needs — combining AI pre-screening with credentialed human expert validation and blockchain-based immutability.

This skill is the AI pre-screening layer, open-sourced for the community.

---

## Skill Structure

```
scientist-dao-reviewer/
├── SKILL.md                          # Main skill — 6-phase review pipeline
└── references/
    ├── citation-verification.md      # Citation fraud patterns & DOI analysis
    ├── statistical-integrity.md      # Statistical anomaly detection
    ├── ai-slop-detection.md          # AI-generated prose indicators
    └── report-templates.md           # Structured output templates
```

---

## The 6-Phase Review Pipeline

| Phase | Name | What It Does |
|-------|------|-------------|
| 0 | Pre-Review Initialization | Scope declaration, capability limits stated upfront |
| 1 | Document Structure Analysis | Maps sections, counts references, checks completeness |
| 2 | Citation Integrity Analysis | Flags suspicious, malformed, or Frankenstein citations |
| 3 | AI Slop Detection | Scores prose for LLM generation patterns |
| 4 | Statistical Integrity | Checks arithmetic, p-value clustering, impossible values |
| 5 | Semantic Consistency | Abstract-conclusion alignment, logic gaps, contradictions |
| 6 | Report Generation | Structured output with GREEN/YELLOW/ORANGE/RED integrity score |

---

## Anti-Hallucination Guard Rails

The skill has 10 hard-coded guard rails that cannot be overridden:

| # | Rule |
|---|------|
| G-0 | Never confirm a citation exists or doesn't exist |
| G-1 | Never invent statistics not present in the paper |
| G-2 | Never claim AI authorship is "proven" |
| G-3 | Mark all external knowledge claims with confidence level |
| G-4 | Use EVIDENCE_LEVEL tags on every finding |
| G-5 | Contradictions require two direct quotes from the paper |
| G-6 | All reviewer calculations must be labeled as such |
| G-7 | Scope declaration required before review begins |
| G-8 | "CANNOT VERIFY" always preferred over a guess |
| G-9 | Every report must include "What the AI Cannot Tell You" |

---

## How to Use

### With Claude (claude.ai)

1. Upload or paste a research paper
2. The skill auto-triggers on any review/validation request
3. The AI will execute all 6 phases and produce a structured integrity report

### With OpenClaw / Compatible Skill Runners

Install the `.skill` package:
```
scientist-dao-reviewer.skill
```

Then submit any manuscript with a review request.

### With Any AI via System Prompt

Copy the contents of `SKILL.md` into your system prompt. Reference the files in `references/` as needed for each analysis phase.

---

## Output Format

Every review produces a structured report including:

- **Report ID**: `SDR-[YYYYMMDD]-[paper abbreviation]`
- **Integrity Score**: GREEN / YELLOW / ORANGE / RED
- **Finding counts** by severity (Critical / Major / Minor)
- **Phase-by-phase summaries**
- **Full flag details** with direct quotes and evidence levels
- **Mandatory human verification checklist**
- **"What the AI Cannot Tell You"** — explicit limits statement

---

## What This Skill Cannot Do

This is a pre-screening tool. It cannot:

- Confirm whether a citation actually exists (requires live database)
- Determine if an effect size is plausible for a specific subfield (requires domain expert)
- Assess whether methodology is appropriate for the research question
- Replace human peer review
- Make publication decisions

It is designed to **assist human validators**, not replace them.

---

## Part of the Scientist DAO Ecosystem

This skill is the AI analysis layer (Layer 2) of the full Scientist DAO pipeline:

```
Manuscript Submission
        ↓
[THIS SKILL] AI Agent Analysis
        ↓
Human Expert Validation (Domain Councils)
        ↓
Blockchain Certification (SHA-3 hash + on-chain anchor)
        ↓
Public Immutable Registry
```

---

## Contributing

This skill is open for community improvement. If you are a:
- **Domain expert** who wants to add field-specific citation red flags
- **Statistician** who wants to expand the statistical integrity checks
- **AI researcher** who wants to improve the slop detection heuristics

Please open a PR or issue. The goal is to make this the most rigorous open-source paper integrity tool available.

---

## License

MIT License — free to use, modify, and distribute with attribution.

---

## Citation

If you use this skill in research or tooling, please cite:

```
Scientist DAO Paper Reviewer Skill (2025).
Open-source scientific integrity pre-screening tool.
https://github.com/scientist-dao/paper-reviewer-skill
```

---

*Built to protect scientific integrity in the age of AI.*
*A short honest review is infinitely better than a long hallucinated one.*
