# Security Policy

## Reporting a Vulnerability

If you discover a security vulnerability in this skill — such as a prompt injection
vector, a guard rail bypass, or a way to force the AI to generate false findings —
please report it responsibly.

**Do not open a public GitHub issue for security vulnerabilities.**

Contact: security@scientistdao.org

We will acknowledge receipt within 48 hours and provide a fix timeline within 7 days.

## Scope

This is a text-based AI skill (Markdown instructions). It has no network access,
no database connections, no authentication systems, and no executable code.

Relevant security concerns include:
- Prompt injection techniques that could cause the AI to bypass guard rails
- Instructions that could trick the AI into fabricating findings
- Social engineering patterns that violate the Anti-Hallucination Oath

## What This Skill Does NOT Contain

- No API keys or credentials of any kind
- No personal data or PII
- No network endpoints or connection strings
- No authentication tokens
- No private keys or certificates

This has been verified by automated scan prior to public release.
