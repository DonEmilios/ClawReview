# AI Slop Detection Reference Guide

## GUARD RAIL REMINDER
You detect PATTERNS. You do NOT render verdicts.
"Exhibits AI generation indicators" ≠ "Written by AI"
Always present findings as probability signals, never as proof.
A human expert may have unconsciously adopted LLM-like writing habits.
Disclosure of AI use makes HIGH scores acceptable.

---

## The Core Paradox

The reviewer is an AI being asked to detect AI writing.
This creates an obligation for extra humility and precision.
Every finding MUST be grounded in a specific, quotable pattern — not a vibe.

---

## Tier 1 — Highest Confidence AI Indicators

These patterns are strong signals because they rarely appear in human academic writing:

### 1. Stock LLM Transition Phrases
Count instances of these exact phrases (case-insensitive):

```
HIGH CONFIDENCE INDICATORS (each = +2 points toward AI score):
- "it is worth noting that"
- "it is important to note that"
- "it is important to consider"
- "this highlights the importance of"
- "plays a crucial role in"
- "in the realm of"
- "in the context of" (when used > 3 times)
- "delve into" / "delve deeper"
- "it is evident that"
- "shed light on"
- "pave the way for"
- "it goes without saying"
- "needless to say"
- "in conclusion, it can be said that"
- "as previously mentioned"
- "as discussed above"
- "the findings of this study suggest"
- "further research is needed" (acceptable once; suspicious > 3 times)
- "a comprehensive understanding"
- "a holistic approach"
```

**Scoring:**
- 0-2 instances: Acceptable (human writers use some of these)
- 3-5 instances: Moderate signal
- 6-9 instances: Strong signal
- 10+: Very strong signal

### 2. Abstract Structure Over-Precision
Human-written abstracts vary in structure. LLM-written abstracts follow a rigid formula:
- Sentence 1: Background/context
- Sentence 2: Problem statement
- Sentence 3: "In this study, we..."
- Sentence 4: Methods summary
- Sentence 5: Results summary
- Sentence 6: "These findings suggest..." or "Our results demonstrate..."
- Sentence 7: "Further research is needed..."

Flag: Abstract that follows this formula with mechanical precision AND contains 3+ stock phrases.

---

## Tier 2 — Moderate Confidence AI Indicators

### 3. Methods Section Passive Voice Saturation
Human researchers narrate their own experiments. LLMs describe experiments in passive voice.

Count in the Methods section:
- Active: "We collected", "We measured", "We analyzed", "Our protocol", "We recruited"
- Passive: "Data was collected", "Samples were measured", "Analysis was performed"

**Flag trigger:** Methods section with > 90% passive voice AND no first-person narration.
Note: Some fields (certain chemistry, physics) use passive voice by convention. Apply field context.

### 4. Uniform Sentence Length Distribution
Measure the length (in words) of 20 consecutive sentences from the Introduction or Discussion.

Human writing distribution: high variance (sentences ranging from 5 to 45+ words)
LLM writing distribution: low variance (most sentences 15-28 words)

```
SENTENCE LENGTH AUDIT (sample 20 sentences):
[list lengths]
Mean: [X] words
Standard deviation: [Y] words

Flag trigger: SD < 5 words across 20+ consecutive sentences
Human academic writing typically shows SD > 8 words
```

### 5. Citation Density Anomalies
LLMs often insert citations at regular intervals regardless of claim importance.

Flag: Every paragraph ends with a citation, even paragraphs making methodological
     decisions that typically don't cite (e.g., "We chose a sample size of 100")

Flag: Citations appear in sections where real researchers typically don't cite
     (e.g., basic mathematical definitions, obvious methodological choices)

---

## Tier 3 — Lower Confidence, Contextual Indicators

### 6. Knowledge Confidence Inversion
LLMs write confidently about vague generalities and vaguely about specifics.
Human experts write precisely about their domain and carefully about periphery.

Flag: Introduction makes sweeping confident claims ("It is well established that...") 
      with weak or absent citations, while specific methods are hedged extensively.

### 7. The Consistency Flatness Problem
Human researchers have opinions. LLMs have "perspectives."

Flag: Discussion section that presents multiple competing theories without ever
      committing to which the data supports. Every position is "worthy of consideration."

### 8. Perfect Acronym Discipline
LLMs always define acronyms on first use and never use them inconsistently.
Human authors sometimes forget, use variants, or are inconsistent.

Note: Perfect acronym discipline alone is NOT a flag — it's just writing quality.
It becomes a mild indicator only in combination with other Tier 1/2 indicators.

---

## The Disclosure Adjustment

If the paper includes a statement like:
- "We used [AI tool] to assist with writing"
- "AI writing assistance was used and reviewed by all authors"
- "ChatGPT/Claude/Copilot was used for [specific purpose]"

THEN:
- Reduce all AI pattern scores by 50%
- Note: "AI use was disclosed. Pattern indicators consistent with disclosed AI assistance."
- Do NOT flag disclosed AI use as a finding — it is acceptable practice

---

## What to Write in the Report

```
AI GENERATION ANALYSIS
======================
Disclosure statement found: YES / NO

Stock phrase count: [N] (threshold: 6+ = strong signal)
Passive voice saturation in methods: [X%] (threshold: >90% = flag)
Sentence length SD: [Y] (threshold: <5 = flag)
Knowledge confidence inversion: DETECTED / NOT DETECTED
Other indicators: [list any Tier 2/3 findings]

Total indicator score: [N points]
AI Pattern Score: LOW / MODERATE / HIGH / VERY HIGH

[If HIGH or VERY HIGH, list the 3 most specific examples with direct quotes]

IMPORTANT: This score reflects linguistic patterns only. It does NOT prove AI
authorship. Human expert review is required before any editorial decision.
AI use that is properly disclosed is acceptable under most journal policies.
```
