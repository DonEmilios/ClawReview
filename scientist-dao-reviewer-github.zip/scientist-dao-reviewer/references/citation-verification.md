# Citation Verification Reference Guide

## The Hallucination Hierarchy of Citations

LLMs hallucinate citations in predictable patterns, ordered from easiest to hardest to detect:

### Tier 1 — Obvious Fabrications (easy to catch)
- Placeholder author names: "John Doe", "Jane Smith", "Author A", "Firstname Lastname"
- Impossible dates: future years, pre-1800 for modern journals
- Nonsense DOIs: random character strings, DOIs without the 10.XXXXX/ prefix
- Generic journal names: "Journal of Science", "International Research Journal" without specifics

### Tier 2 — Plausible Fabrications (moderate difficulty)
- Real-sounding author names that don't match the field's naming conventions
- Real journal name + impossible volume/issue combination for that journal's publication history
- Title that sounds academic but is grammatically broken or internally contradictory
- Page ranges that are implausibly small (p. 1-2) for a full research article

### Tier 3 — Frankenstein Citations (hardest to catch without databases)
- Real author(s) from the field + fabricated title
- Real paper title + wrong authors
- Real paper + wrong venue (correct title, wrong journal)
- Real paper + wrong year (off by several years)
- Blended citations: elements from two real papers merged into one fake entry

## Citation Format Red Flags by Field

### Life Sciences / Medicine
- Expected: PubMed ID (PMID) often present
- Red flag: DOI that doesn't follow 10.1XXX/ pattern for major publishers
- Red flag: Author list with > 20 authors but no "et al." abbreviation
- Red flag: "Unpublished manuscript" cited as primary evidence for a clinical claim

### Computer Science / AI
- Expected: arXiv IDs often present (arXiv:YYYY.NNNNN)
- Red flag: Conference papers without page numbers (most CS conferences paginate)
- Red flag: Workshop papers cited as if peer-reviewed main conference papers
- Red flag: arXiv preprint cited with a publication venue that doesn't match

### Social Sciences
- Expected: DOI and journal volume/issue
- Red flag: Effect sizes from cited studies that are implausibly consistent with current paper
- Red flag: "Personal communication" cited for quantitative data

## DOI Pattern Verification

You cannot query a DOI. But you can check its FORMAT:

```
VALID DOI PATTERNS:
  10.1000/xyz123        ← publisher prefix / article identifier
  10.1038/nature12345   ← Nature (10.1038)
  10.1016/j.cell.2024   ← Elsevier (10.1016)
  10.1126/science.abc   ← Science (10.1126)
  10.1056/NEJMoa123456  ← NEJM (10.1056)
  10.1001/jama.2024.123 ← JAMA (10.1001)

INVALID DOI PATTERNS (flag these):
  10.1234              ← missing article identifier after /
  doi:10.1234/abc      ← "doi:" prefix should not be part of the DOI itself
  https://doi.org/...  ← URL, not a DOI (note for human to resolve)
  10.99999/anything    ← registrant prefix 99999 is not assigned
  [random alphanumeric with no 10. prefix]
```

## The Citation-to-Claim Alignment Check

For each major claim supported by a citation, assess:

1. **Topical relevance**: Does the cited title suggest it's about the same topic as the claim?
   - PLAUSIBLE: Title clearly relates to the claimed finding
   - QUESTIONABLE: Title is adjacent but not directly relevant
   - IMPLAUSIBLE: Title has no apparent connection to the claim

2. **Temporal plausibility**: Was the cited work published before the current paper?
   - Flag: Citing a 2026 paper in a 2024 manuscript

3. **Self-citation saturation**: Count self-citations as % of total references
   - Flag: > 30% self-citations without explanation
   - Note: High self-citation is not automatically fraudulent, but warrants disclosure check

## What to Write When You Cannot Verify

NEVER write: "This citation does not exist."
NEVER write: "I could not find this paper." (implies you searched — you didn't)
NEVER write: "This appears to be fabricated." (without specific anomaly evidence)

ALWAYS write one of:
- "This citation exhibits [specific anomaly]: [quote the anomaly]. Human database verification required."
- "This citation cannot be confirmed plausible based on format alone. No specific anomaly detected. Flagged for routine human verification."
- "This citation appears internally consistent in format. No anomalies detected. Routine verification recommended."
