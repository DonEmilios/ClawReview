# Report Templates Reference

## Quick-Copy Flag Templates

Use these templates to ensure consistency across all findings.
Copy, fill in brackets, remove unused fields.

---

### CITATION FLAG

```
CITATION FLAG [CF-XXX]
══════════════════════════════════════════════════════════════
Severity:        CRITICAL | MAJOR | MINOR
Reference #:     [N in bibliography]
Full citation:   "[exact text as written in paper]"
Anomaly type:    PLACEHOLDER_NAME | MALFORMED_DOI | DATE_ANOMALY |
                 FRANKENSTEIN_SUSPECTED | VENUE_SUSPICIOUS |
                 TITLE_INCOHERENT | FORMAT_BROKEN | RELEVANCE_MISMATCH
Specific issue:  [Quote the exact part that triggers the flag]
Evidence level:  CONFIRMED_ANOMALY | SUSPECTED_ANOMALY | LOW_CONCERN
Action required: HUMAN_VERIFY_DATABASE | AUTHOR_CLARIFICATION | MONITOR
Human note:      [What the human reviewer should specifically check]
══════════════════════════════════════════════════════════════
```

---

### STATISTICAL FLAG

```
STATISTICAL FLAG [SF-XXX]
══════════════════════════════════════════════════════════════
Severity:        CRITICAL | MAJOR | MINOR
Location:        [Section name, paragraph N, Table N, Figure N]
Reported value:  "[exact value as written]"
Anomaly type:    IMPOSSIBLE_VALUE | THRESHOLD_CLUSTERING |
                 IMPLAUSIBLE_EFFECT | INTERNAL_INCONSISTENCY |
                 MISSING_STATISTIC | ROUNDING_SUSPICIOUS
Specific issue:  [Describe exactly what is wrong]
Evidence level:  CONFIRMED (arithmetic) | SUSPECTED (pattern)
Reviewer calc:   [REVIEWER CALCULATION: show arithmetic if applicable]
                 [Label ALL calculations as reviewer-generated]
Action required: HUMAN_STATISTICIAN_REVIEW | AUTHOR_CLARIFICATION |
                 DATA_VERIFICATION
══════════════════════════════════════════════════════════════
```

---

### AI SLOP FLAG

```
AI PATTERN FLAG [AP-XXX]
══════════════════════════════════════════════════════════════
Severity:        MODERATE | ELEVATED | HIGH
Location:        [Section name, paragraph N]
Pattern type:    STOCK_PHRASE | PASSIVE_SATURATION | UNIFORM_RHYTHM |
                 KNOWLEDGE_INVERSION | INTERNAL_REPETITION | OTHER
Direct quote:    "[exact text from paper exhibiting the pattern]"
Pattern count:   [How many times this pattern appears in the document]
Evidence level:  SUSPECTED (pattern-based — not proof of AI authorship)
Disclosure:      AI use disclosed: YES / NO
Note:            "This is a linguistic indicator, not proof of AI authorship.
                  Human expert review required before editorial action."
══════════════════════════════════════════════════════════════
```

---

### LOGICAL CONSISTENCY FLAG

```
LOGICAL FLAG [LF-XXX]
══════════════════════════════════════════════════════════════
Severity:        CRITICAL | MAJOR | MINOR
Type:            CONTRADICTION | UNSUPPORTED_CLAIM | METHODS_GAP |
                 ABSTRACT_MISMATCH | CONCLUSION_OVERREACH
Location A:      [Section, paragraph] — "[exact quote]"
Location B:      [Section, paragraph] — "[exact quote]"  (for contradictions)
Issue:           [Describe the logical problem in plain language]
Evidence level:  ANALYTICAL_JUDGMENT — subject to domain expert review
Action required: AUTHOR_CLARIFICATION | DOMAIN_EXPERT_REVIEW
══════════════════════════════════════════════════════════════
```

---

## Severity Definitions

### CRITICAL
Requires resolution before any publication or further use of the paper.
Examples: Impossible statistical value, clear placeholder author name,
mathematical proof of internal inconsistency.

### MAJOR
Warrants author response and human expert review before publication decision.
Examples: Suspicious p-value clustering, high AI pattern score without disclosure,
Frankenstein citation suspected, abstract-conclusion mismatch.

### MINOR
Note for human reviewer's attention; does not block publication.
Examples: Missing conflict of interest statement, single stock phrase, 
one citation with slightly unusual format.

---

## Integrity Score Calculation

```
RED triggers (any one = RED overall):
- 1+ CRITICAL citation flag
- 1+ CONFIRMED statistical impossibility
- 3+ MAJOR flags of any type
- AI Pattern Score = VERY HIGH with no disclosure

ORANGE triggers (any one = ORANGE overall):
- 2+ MAJOR citation flags
- 2+ SUSPECTED statistical flags
- AI Pattern Score = HIGH with no disclosure
- 1+ CRITICAL logical flag

YELLOW triggers:
- 1-2 MINOR flags of any type
- AI Pattern Score = MODERATE
- Structural sections missing (data availability, conflict of interest)

GREEN:
- 0-1 MINOR flags
- All structural sections present
- AI Pattern Score = LOW
- No anomalies detected
```

---

## The "What the AI Cannot Tell You" Standard Section

Always include this verbatim at the end of every report:

```
WHAT THIS AI REVIEW CANNOT TELL YOU
=====================================
The following require human domain expert assessment:

1. CITATION EXISTENCE: Whether any flagged or unflagged citation
   actually exists and says what the paper claims it says.
   → Required action: Human database verification (CrossRef, PubMed,
     Semantic Scholar, Google Scholar) for all citations.

2. EFFECT SIZE VALIDITY: Whether reported effect sizes are plausible
   for this specific subfield and research design.
   → Required action: Domain expert statistician review.

3. METHODOLOGY APPROPRIATENESS: Whether the chosen statistical methods
   and experimental design are appropriate for the research question.
   → Required action: Domain expert methodologist review.

4. CONCLUSION VALIDITY: Whether the authors' conclusions are justified
   by their data given field-specific knowledge.
   → Required action: Domain expert peer review.

5. CONFLICT OF INTEREST: Whether undisclosed financial or personal
   relationships may have influenced the results.
   → Required action: Editorial conflict of interest screening.

6. REPRODUCIBILITY: Whether the methods are described in sufficient
   detail for independent replication.
   → Required action: Human expert reproducibility assessment.

This automated review is a pre-screening tool. It does not replace,
and should not substitute for, human expert peer review.
```
