# Statistical Integrity Reference Guide

## GUARD RAIL REMINDER
You are checking arithmetic and internal consistency ONLY.
You are NOT performing original statistical analysis.
You are NOT determining whether a statistical method is appropriate (that requires human expertise).
Label every calculation: [REVIEWER CALCULATION — not from paper]

---

## The Carlisle Method — P-Value Distribution Analysis

John Carlisle's method detects fabricated data by analyzing whether reported p-values
are distributed as expected under real experimental conditions.

**What you can check without software:**
- Are multiple p-values suspiciously clustered just below 0.05?
  (e.g., p=0.049, p=0.048, p=0.046 across unrelated outcomes)
- Are p-values reported with suspiciously uniform precision?
  (all to 3 decimal places, all ending in "8" or "9")
- Is p=0.000 reported? This is mathematically impossible — it means the software
  rounded a very small number and the author copied it without understanding.

**Flag trigger:**
```
P-VALUE CLUSTERING FLAG
=======================
Values found: [list all p-values from the paper]
Pattern observed: [describe]
Threshold analysis: [N] out of [total] p-values fall between 0.040-0.050
Concern level: LOW (1-2) / MODERATE (3-4) / HIGH (5+)
Note: Clustering alone is not proof of fabrication. Human statistician review required.
```

---

## Impossible or Implausible Statistical Values

### Values That Are Mathematically Impossible
- p = 0.000 (impossible — must be p < 0.001)
- r = 1.000 or r = -1.000 (perfect correlation, essentially impossible in real data)
- Sensitivity = 100% AND Specificity = 100% simultaneously (no diagnostic test achieves this)
- Percentage > 100% or < 0%
- Probability > 1 or < 0
- Standard deviation = 0 with N > 1 (impossible unless all values are literally identical)
- Negative variance or standard deviation
- Chi-square < 0

### Values That Are Extremely Suspicious
- Cohen's d > 3.0 in social/behavioral sciences (effect sizes this large are extraordinarily rare)
- r > 0.95 in any observational social science study
- Test-retest reliability = 1.0
- Any effect size that is exactly a round number (r = 0.50, d = 1.00) — real data rarely lands exactly

---

## Internal Arithmetic Checks

These are the ONLY checks you can mark as CONFIRMED rather than SUSPECTED:

### Percentage Consistency
All percentages within a group must sum to 100% (±1% for rounding).
```
CHECK: Table reports Group A = 45%, Group B = 38%, Group C = 12%
SUM [REVIEWER CALCULATION]: 45 + 38 + 12 = 95% ≠ 100%
FLAG: 5% unaccounted for — author clarification required
```

### N Consistency
The sample size N reported in Methods must match N in Results tables.
```
CHECK: Methods states "N = 247 participants"
Results Table 1 shows: Group 1 (n=124) + Group 2 (n=118) = 242
DISCREPANCY [REVIEWER CALCULATION]: 247 - 242 = 5 participants unaccounted for
FLAG: Sample size inconsistency — author clarification required
```

### Mean Plausibility Within Range
If min, max, and mean are all reported, check: min ≤ mean ≤ max
```
CHECK: Min = 12, Max = 45, Mean = 52
IMPOSSIBLE [REVIEWER CALCULATION]: Mean (52) > Max (45)
FLAG: CONFIRMED IMPOSSIBILITY — arithmetic check
```

### Confidence Interval Consistency
A 95% CI should be approximately mean ± 1.96 × SE
If both CI and SE are reported, check rough consistency.
```
Mean = 24.3, SE = 2.1, reported 95% CI = [20.2, 28.4]
Expected CI width [REVIEWER CALCULATION]: 2 × 1.96 × 2.1 = 8.23
Actual CI width: 28.4 - 20.2 = 8.2 ✓ CONSISTENT
```

---

## Field-Specific Effect Size Norms

Use these only to flag UNUSUALLY LARGE effects for human expert review.
Never use these to declare a result fabricated.

| Field | Typical r range | Suspicious threshold |
|-------|----------------|---------------------|
| Social psychology | 0.10 - 0.40 | > 0.70 |
| Clinical trials (drug efficacy) | 0.20 - 0.50 | > 0.85 |
| Cognitive psychology | 0.30 - 0.60 | > 0.80 |
| Educational interventions | 0.10 - 0.40 | > 0.70 |
| Genetics (GWAS) | 0.01 - 0.15 | > 0.50 |
| Machine learning (benchmark) | 0.80 - 0.99 | N/A (high values expected) |

**Always write:** "This effect size of [X] is unusually large for [field] where typical
values range from [range]. This warrants human domain expert review."
NEVER write: "This effect size is fabricated."

---

## Data Availability Red Flags

- Results reported from a dataset with no DOI, repository link, or availability statement
- "Data available upon reasonable request" — this is acceptable but note it as unverifiable
- "Data cannot be shared due to privacy" for aggregate statistics (aggregate data can almost always be shared)
- Figures show data distributions that look too perfect (perfectly bell-shaped, no outliers)
